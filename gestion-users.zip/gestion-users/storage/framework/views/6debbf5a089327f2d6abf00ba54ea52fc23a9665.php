
<?php $__env->startSection('title', 'Liste des utilisateurs'); ?>
<?php $__env->startSection('titre', 'Liste des utilisateurs'); ?>
<?php $__env->startSection('contenu'); ?>
    <?php if(!empty($utilisateurs)): ?>
        <table>
            <th>Prenom</th>
            <th>Nom</th>
            <th>Login</th>
            <th>Password</th>
            <th colspan="3">Action</th>
            
            <?php $__currentLoopData = $utilisateurs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $utilisateur): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
                <tr>
                    <td><?php echo e($utilisateur->prenom); ?></td>
                    <td><?php echo e($utilisateur->nom); ?></td>
                    <td><?php echo e($utilisateur->login); ?></td>
                    <td><?php echo e($utilisateur->password); ?></td>
                    <td><a href="/users/<?php echo e($utilisateur->id); ?>"><i class="fas fa-eye" id="eye"></i></a></td>
                    <td><a href="/users/delete/<?php echo e($utilisateur->id); ?>" onclick="confirm('Etes vous sur de Supprimer')"><i class="fas fa-trash" id="delete"></i></a></td>
                    <td><a href="/users/update/<?php echo e($utilisateur->id); ?>"><i class="fas fa-user-edit" id="edit"></i></a></td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </table>
        <?php else: ?>
        <p>La liste des utilisateurs est vides</p>
    <?php endif; ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\hp\OneDrive\Documents\TP Laravel\gestion-users\resources\views/users/list.blade.php ENDPATH**/ ?>