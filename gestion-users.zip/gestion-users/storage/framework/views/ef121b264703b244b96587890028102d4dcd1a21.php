
<?php $__env->startSection('title', 'Affichage user'); ?>
<?php $__env->startSection('titre', 'Profil d\'un user'.$utilisateur->id); ?>
<?php $__env->startSection('contenu'); ?>
    <table>
        <tr>
            <th>Caracteristique</th>
            <th>Valeur</th>
        </tr>
        <tr>
            <td>ID</td>
            <td><?php echo e($utilisateur->id); ?></td>
        </tr>
        <tr>
            <td>NOM</td>
            <td><?php echo e($utilisateur->nom); ?></td>
        </tr>
        <tr>
            <td>PRENOM</td>
            <td><?php echo e($utilisateur->prenom); ?></td>
        </tr>
        <tr>
            <td>LOGIN</td>
            <td><?php echo e($utilisateur->login); ?></td>
        </tr>
        <tr>
            <td>PASSWORD</td>
            <td><?php echo e($utilisateur->password); ?></td>
        </tr>
    </table>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\hp\OneDrive\Documents\TP Laravel\gestion-users\resources\views/users/show.blade.php ENDPATH**/ ?>