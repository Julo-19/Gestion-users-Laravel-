
<?php $__env->startSection('title', 'Ajouter'); ?>
<?php $__env->startSection('titre', 'Ajouter un user'); ?>
<?php $__env->startSection('contenu'); ?>
    <form method="POST" action="/users/create" class="formulaire">
        <?php echo csrf_field(); ?>
        <input type="text" name="nom" placeholder="Nom" autocomplete="off" value="<?php echo e(old('nom')); ?>"> <br> <br>
        <input type="text" name="prenom"  placeholder="Prenom" autocomplete="off"  value="<?php echo e(old('prenom')); ?>"> <br> <br>
        <input type="text" name="login" placeholder="Login" autocomplete="off" value="<?php echo e(old('login')); ?>"> <br> <br>
        <input type="password" name="password" placeholder="Mot de passe" value="<?php echo e(old('password')); ?>"> <br> <br>
        <input type="submit" value="Ajouter" id="valider">
    </form>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\hp\OneDrive\Documents\TP Laravel\gestion-users\resources\views/users/create.blade.php ENDPATH**/ ?>