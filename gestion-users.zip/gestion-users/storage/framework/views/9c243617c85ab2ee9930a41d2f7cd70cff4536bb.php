<!DOCTYPE html>
<html>
    <head>
        <meta charset="UTF-8">
        <title> <?php echo $__env->yieldContent('title', 'Accueil'); ?> </title>
        <link rel="stylesheet" href="/css/style.css">
        <link rel="preconnect" href="https://fonts.googleapis.com">
        <link rel="preconnect" href="https://fonts.googleapis.com">
        <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
        <link href="https://fonts.googleapis.com/css2?family=Comforter+Brush&family=Fredoka&family=Grenze:wght@400;600&family=Josefin+Sans:wght@600&family=Raleway:wght@300&display=swap" rel="stylesheet">
        <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.13.0/css/all.min.css" rel="stylesheet">
    </head>
    <body>
        <header>Gestion des Utilisateurs</header>
        <nav>
            <ul>
                <li><a href="/">Accueil</a></li>
                <li><a href="/users/list">Lister</a></li>
                <li><a href="/users/create">Ajouter </a></li>
                
                
            </ul>
        </nav>

        <section>
            <?php if(session('message')): ?>
                <div class="alert alert-<?php echo e(session('status') ? 'success' : 'danger'); ?> ">
                    <?php echo e(session ('message')); ?>

                </div>
            <?php endif; ?>
            <h1 id="titre-principal"><?php echo $__env->yieldContent('titre'); ?></h1>
            <?php echo $__env->yieldContent('contenu'); ?>
        </section>
        <footer>
            By Julo &copy;Mars 2022 
           
        </footer>
    </body>
</html><?php /**PATH C:\Users\hp\OneDrive\Documents\TP Laravel\gestion-users\resources\views/layout/main.blade.php ENDPATH**/ ?>