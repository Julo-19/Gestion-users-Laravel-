
<?php $__env->startSection('title', 'modifier user'); ?>
<?php $__env->startSection('titre', 'Modifier un user'); ?>
<?php $__env->startSection('contenu'); ?>
    <form method="POST" action="/users/update/<?php echo e($utilisateur->id); ?>">
        <?php echo csrf_field(); ?>
        <input type="text" name="nom" placeholder="Nom" value="<?php echo e($utilisateur->nom); ?>"> <br> <br>
        <input type="text" name="prenom"  placeholder="Prenom" value="<?php echo e($utilisateur->prenom); ?>"> <br> <br>
        <input type="text" name="login" placeholder="Login" value="<?php echo e($utilisateur->login); ?>"> <br> <br>
        <input type="password" name="password" placeholder="Mot de passe" value="<?php echo e($utilisateur->password); ?>"> <br> <br>
        <input type="submit" value="Modifier">
    </form>
<?php $__env->stopSection(); ?> 
<?php echo $__env->make('layout.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\hp\OneDrive\Documents\TP Laravel\gestion-users\resources\views/users/edit.blade.php ENDPATH**/ ?>