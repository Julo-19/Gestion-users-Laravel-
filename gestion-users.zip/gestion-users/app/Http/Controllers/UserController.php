<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

use function PHPUnit\Framework\returnSelf;

class UserController extends Controller
{
    public function list()
    {
        $utilisateurs = DB::select('SELECT * FROM utilisateur');
        return view('users.list', compact('utilisateurs'));
    }

    public function create()
    {
        return view('users.create');
    }

    public function store()
    {
        if (!empty(request('nom')) && !empty(request('prenom')) && !empty(request('login')) && !empty(request('password'))) 
        {
            $utilisateur = DB::select('SELECT * FROM utilisateur WHERE login = ?', [request('login')]);
            if (empty($utilisateur)) 
            {
                $requete = 'INSERT INTO utilisateur(nom, prenom, login, password) VALUE (:nom, :prenom, :login, :password)';
                $statuts = DB::insert($requete, [
       
                   'nom' => request('nom'),
                   'prenom' => request('prenom'),
                   'login' => request('login'),
                   'password' => request('password'),
               ]);
       
               if($statuts === true)
               {
                   $message =  'Ajout effectue avec succés ';
               }
               else
               {
                   $message = 'Echec';
               }
               return redirect('/users/list')->with(['status' => $statuts, 'message' => $message]);
            }
            else
            {
                return back()->withInput()->with('message', 'Erreur Ce login existe déja');
            }
        }
       else
       {
           return back()->withInput()->with('message', 'Erreur Vous devez renseigner toutes les informations');
       }
       

    }

    public  function delete($id)
    {
        $affected = DB::delete('DELETE FROM utilisateur WHERE id = ?', [$id]);
        if ($affected > 0)
         {
            $message = 'Suppression avec succes';
        }
        else
        {
            $message = 'Aucun utilisateur n\'a ete supprime';
        }
        return redirect('/users/list')-> with(['status' => $affected, 'message' => $message]);
    }

    public function edit($id)
    {
        $utilisateur = DB::select('SELECT * FROM utilisateur WHERE id = ?', [$id]);
        
      if ($utilisateur)
       {
        $utilisateur = $utilisateur[0];
        return view('users.edit', compact('utilisateur'));
      }
      else
       {
          abort(404);
      }
    }

    public function update($id)
    {
      
        if (!empty(request('nom')) && !empty(request('prenom')) && !empty(request('login')) && !empty(request('password'))) 
        {
            $requete = ('UPDATE utilisateur SET nom = :nom, prenom = :prenom, login = :login, password = :password WHERE id = :id');
            $affected = DB::update($requete, [
                'id' => $id,
                'nom' => request('nom'), 
                'prenom' => request('prenom'),
                'login' => request('login'),
                'password' => request('password'),
            ]);
    
            if ($affected > 0)
             {
                $message = 'Modificaion avec succes';
            }
            else
            {
                $message = 'Aucun utilisateur n\'a ete modifie';
            }
            return redirect('/users/list')-> with(['status' => $affected, 'message' => $message]);
        }
        else
        {
             return back()->withInput()->with('message', 'Erreur Vous devez renseigner toutes les informations');
        }
      
       
    }

    public function show($id)
    {
        $utilisateur = DB::select('SELECT * FROM utilisateur WHERE id=?', [$id]);
        $utilisateur = $utilisateur[0];
        return view('users.show', compact('utilisateur'));
    }
}

