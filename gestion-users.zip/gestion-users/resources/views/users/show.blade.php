@extends('layout.main')
@section('title', 'Affichage user')
@section('titre', 'Profil d\'un user'.$utilisateur->id)
@section('contenu')
    <table>
        <tr>
            <th>Caracteristique</th>
            <th>Valeur</th>
        </tr>
        <tr>
            <td>ID</td>
            <td>{{ $utilisateur->id }}</td>
        </tr>
        <tr>
            <td>NOM</td>
            <td>{{ $utilisateur->nom }}</td>
        </tr>
        <tr>
            <td>PRENOM</td>
            <td>{{ $utilisateur->prenom }}</td>
        </tr>
        <tr>
            <td>LOGIN</td>
            <td>{{ $utilisateur->login }}</td>
        </tr>
        <tr>
            <td>PASSWORD</td>
            <td>{{ $utilisateur->password }}</td>
        </tr>
    </table>
@endsection
