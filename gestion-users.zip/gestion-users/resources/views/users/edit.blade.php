@extends('layout.main')
@section('title', 'modifier user')
@section('titre', 'Modifier un user')
@section('contenu')
    <form method="POST" action="/users/update/{{ $utilisateur->id }}">
        @csrf
        <input type="text" name="nom" placeholder="Nom" value="{{ $utilisateur->nom }}"> <br> <br>
        <input type="text" name="prenom"  placeholder="Prenom" value="{{ $utilisateur->prenom }}"> <br> <br>
        <input type="text" name="login" placeholder="Login" value="{{ $utilisateur->login }}"> <br> <br>
        <input type="password" name="password" placeholder="Mot de passe" value="{{ $utilisateur->password }}"> <br> <br>
        <input type="submit" value="Modifier">
    </form>
@endsection 