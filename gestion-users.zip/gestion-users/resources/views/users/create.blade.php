@extends('layout.main')
@section('title', 'Ajouter')
@section('titre', 'Ajouter un user')
@section('contenu')
    <form method="POST" action="/users/create" class="formulaire">
        @csrf
        <input type="text" name="nom" placeholder="Nom" autocomplete="off" value="{{ old('nom') }}"> <br> <br>
        <input type="text" name="prenom"  placeholder="Prenom" autocomplete="off"  value="{{ old('prenom') }}"> <br> <br>
        <input type="text" name="login" placeholder="Login" autocomplete="off" value="{{ old('login') }}"> <br> <br>
        <input type="password" name="password" placeholder="Mot de passe" value="{{ old('password') }}"> <br> <br>
        <input type="submit" value="Ajouter" id="valider">
    </form>
@endsection