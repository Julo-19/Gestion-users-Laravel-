@extends('layout.main')
@section('title', 'Liste des utilisateurs')
@section('titre', 'Liste des utilisateurs')
@section('contenu')
    @if(!empty($utilisateurs))
        <table>
            <th>Prenom</th>
            <th>Nom</th>
            <th>Login</th>
            <th>Password</th>
            <th colspan="3">Action</th>
            
            @foreach($utilisateurs as $utilisateur) 
                <tr>
                    <td>{{ $utilisateur->prenom }}</td>
                    <td>{{ $utilisateur->nom }}</td>
                    <td>{{ $utilisateur->login}}</td>
                    <td>{{ $utilisateur->password }}</td>
                    <td><a href="/users/{{ $utilisateur->id }}"><i class="fas fa-eye" id="eye"></i></a></td>
                    <td><a href="/users/delete/{{ $utilisateur->id }}" onclick="confirm('Etes vous sur de Supprimer')"><i class="fas fa-trash" id="delete"></i></a></td>
                    <td><a href="/users/update/{{ $utilisateur->id }}"><i class="fas fa-user-edit" id="edit"></i></a></td>
                </tr>
            @endforeach
        </table>
        @else
        <p>La liste des utilisateurs est vides</p>
    @endif
@endsection