<!DOCTYPE html>
<html>
    <head>
        <meta charset="UTF-8">
        <title> @yield('title', 'Accueil') </title>
        <link rel="stylesheet" href="/css/style.css">
        <link rel="preconnect" href="https://fonts.googleapis.com">
        <link rel="preconnect" href="https://fonts.googleapis.com">
        <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
        <link href="https://fonts.googleapis.com/css2?family=Comforter+Brush&family=Fredoka&family=Grenze:wght@400;600&family=Josefin+Sans:wght@600&family=Raleway:wght@300&display=swap" rel="stylesheet">
        <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.13.0/css/all.min.css" rel="stylesheet">
    </head>
    <body>
        <header>Gestion des Utilisateurs</header>
        <nav>
            <ul>
                <li><a href="/">Accueil</a></li>
                <li><a href="/users/list">Lister</a></li>
                <li><a href="/users/create">Ajouter </a></li>
                
                
            </ul>
        </nav>

        <section>
            @if(session('message'))
                <div class="alert alert-{{ session('status') ? 'success' : 'danger' }} ">
                    {{ session ('message') }}
                </div>
            @endif
            <h1 id="titre-principal">@yield('titre')</h1>
            @yield('contenu')
        </section>
        <footer>
            By Julo &copy;Mars 2022 
           {{-- <div style="color: #2D2F2F;"> <i class="fas fa-phone" id="phone"> 33 837 15 33 </i></div> --}}
        </footer>
    </body>
</html>